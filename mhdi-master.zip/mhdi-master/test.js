const axios = require("axios");

async function getCryptoPriceCMC(cryptoSymbol, convertCurrency, apiKey) {
  try {
    const url =
      "https://pro-api.coinmarketcap.com/v1/cryptocurrency/quotes/latest";
    const response = await axios.get(url, {
      params: {
        symbol: cryptoSymbol,
        convert: convertCurrency,
      },
      headers: {
        "X-CMC_PRO_API_KEY": apiKey,
      },
    });
    const data = response.data;
    console.log(
      `The current price of ${cryptoSymbol} in ${convertCurrency} is: $${data.data[cryptoSymbol].quote[convertCurrency].price}`
    );
  } catch (error) {
    console.error("Error fetching the cryptocurrency price:", error);
  }
}

// Replace 'YOUR_COINMARKETCAP_API_KEY' with your actual CoinMarketCap API key
const apiKey = "3bd8e467-7d33-4c65-9c34-003467fd37a9";
getCryptoPriceCMC("BTC", "USD", apiKey);
