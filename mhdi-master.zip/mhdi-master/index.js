require("dotenv").config();
const express = require("express");
const app = express();

//--------------cors
const cors = require("cors");
app.use(cors());
//--------------cors

//--------------bodyParser
const bodyParser = require("body-parser");
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
//--------------bodyParser

//--------------routes
const blockchain = require("./routers/blockchain");
app.use("/blockchain", blockchain);
const jwt = require("./routers/jwt");
app.use("/jwt", jwt);
const SMTP = require("./routers/SMTP");
app.use("/SMTP", SMTP);
const API = require("./routers/API");
app.use("/api", API);

app.get("/test", async (req, res) => {
  const fetchTX = require("./tools/blockchain/polygon/fetchTX");
  const txns = await fetchTX("0xE83E8EbFBa4183040E4cCb8780737384c087F449");

  // Function to check if the date is within the current month
  function isThisMonth(date) {
    const today = new Date();
    return (
      date.getMonth() === today.getMonth() &&
      date.getFullYear() === today.getFullYear()
    );
  }

  const thisMonthTransactions = txns.filter((txn) => {
    const timestamp = parseInt(txn.timeStamp);
    const txnDate = new Date(timestamp * 1000);
    return isThisMonth(txnDate);
  });

  // You can send today's transactions as a response if you are using Express.js
  res.json({ txns: thisMonthTransactions });
});

//--------------routes

//--------------Cron
const {
  validateCrypto,
  validateTX,
  setGasFeeOfNetworkTo,
  setCoinPriceTo,
} = require("./tools/cronjob");
validateCrypto();
validateTX();
setGasFeeOfNetworkTo();
setCoinPriceTo();
//--------------Cron

app.listen(3001, () => {
  console.log("running on 3001");
});
