const TronWalletHD = require("tron-wallet-hd");

const wallet = new TronWalletHD();

const seedPhrase =
  "apart grace comfort room match left consider error mobile left demise report";
wallet.setSeedPhrase(seedPhrase);

const mnemonic = wallet.generateMnemonic();

const account = wallet.getAccountFromMnemonic(mnemonic, 0);

//const account = wallet.generateAccount(0);

const publicKey = account.getPublicKey();

const privateKey = account.getPrivateKey();

const address = account.getAddress();
