/*const { Alchemy, Network, Wallet, Utils } = require("alchemy-sdk");
const dotenv = require("dotenv");

dotenv.config();
const PRIVATE_KEY = "423cd3039e4d17f039d6362ee3a12c69bc32c2e082bc7a5e4ece1d9d84d0977e";

const settings = {
  apiKey: "GvCMBGz_vhib18YaMwBE8nJeo_klemRT",
  network: Network.ETH_MAINNET,
};
const alchemy = new Alchemy(settings);

let wallet = new Wallet(PRIVATE_KEY);
amountOfCoin = 0.00001;
to = '0xE83E8EbFBa4183040E4cCb8780737384c087F449'

async function sendMoney() {

  try {
      

    const nonce = await alchemy.core.getTransactionCount(
      wallet.address,
      "latest"
    );

    let transaction = {
      to,
      value: Utils.parseEther(amountOfCoin.toString().slice(0, 15)),
      gasLimit: "21000",
      maxPriorityFeePerGas: Utils.parseUnits("30", "gwei"),
      maxFeePerGas: Utils.parseUnits("3000", "gwei"),
      nonce: nonce,
      type: 2,
      chainId: 137,
    };

    let rawTransaction = await wallet.signTransaction(transaction);
    let tx = await alchemy.core.sendTransaction(rawTransaction);
    console.log("Sent transaction", tx);

    return {
      success: true,
      hash: tx.hash
    }
    
  } catch (error) {
    return {
      success: false,
      error
    }
  }
}

sendMoney()
.then(result => console.log(result))
.catch(error => console.error(error));

/*
*/

const { PrismaClient } = require("@prisma/client");
const sendMoney_general = require("./tools/blockchain/sendMoneyGeneral");
const prisma = new PrismaClient();
const main = async () => {
  const coin = await prisma.coin.findUnique({
    where: { coinNonce: "DupQFez78k" },
  });
  const result = await sendMoney_general(
    "b30c0976914b61e0638c7e8bcbfdbcbaca3deb498115b5af239c4fe7409e6288",
    coin,
    0.12,
    "0xfF417cea171f30c05718540783E59AAF0d51de3D"
  );
  console.log(result);
};
main();
