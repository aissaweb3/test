const express = require("express");
const bcrypt = require("bcrypt");
const router = express.Router();

const { PrismaClient } = require("@prisma/client");
const create = require("../tools/deposit/create");
const prisma = new PrismaClient();

const auth = async (pub, pri) => {
  if (!pub || !pri)
    return {
      success: true,
      isAuth: false,
      msg: "Incorrect Credentials.",
    };

  const merchant = await prisma.merchant.findUnique({
    where: { pub_KEY: pub, verified: true, accepted: true },
  });

  if (!merchant)
    return {
      success: true,
      isAuth: false,
      msg: "Incorrect Credentials.",
    };

  const auth = await bcrypt.compare(pri, merchant.pri_KEY);
  if (!auth)
    return {
      success: true,
      isAuth: false,
      msg: "Incorrect Credentials.",
    };

  return {
    success: true,
    isAuth: true,
    msg: "Merchant Exists, Your Credentials Are Correct.",
  };
};

router.post("/getMerchant", async (req, res) => {
  const { pub, pri } = req.body;

  const response = await auth(pub, pri);
  return res.json(response);
});

router.post("/getPaymentLink", async (req, res) => {
  const { pub, pri, amount, clientMetaData } = req.body;

  const response = await auth(pub, pri);

  if (response.isAuth) {
    const merchant = await prisma.merchant.findUnique({
      where: {
        pub_KEY: pub,
      },
    });

    try {
      const data = await create({
        amountUSD: amount,
        Data: clientMetaData,
        pub_KEY: pub,
        JWT_KEY: merchant.jwt_KEY,
        merchant,
      });
      return res.json({
        success: true,
        paymentLink: data.paymentLink,
        msg: "success",
      });
    } catch (error) {
      console.log(error);
      return res.json({
        success: true,
        paymentLink: null,
        msg: "server error",
      });
    }
  } else {
    return res.json({
      success: response.success,
      paymentLink: null,
      msg: response.msg,
    });

    /*success: true,
      paymentLink: response.data.paymentLink,
      msg: response.data.msg,*/
  }
});

router.post("/getManualPaymentLink", async (req, res) => {
  const { pub, amount, clientMetaData } = req.body;

  const merchant = await prisma.merchant.findUnique({
    where: {
      pub_KEY: pub,
    },
  });

  if (!merchant)
    return res.json({
      success: true,
      paymentLink: null,
      msg: "Merchant Not Valid.",
    });

  try {
    const data = await create({
      amountUSD: amount,
      Data: clientMetaData,
      pub_KEY: pub,
      JWT_KEY: merchant.jwt_KEY,
      merchant,
    });
    return res.json({
      success: true,
      paymentLink: data.paymentLink,
      msg: "success",
    });
  } catch (error) {
    console.log(error);
    return res.json({
      success: true,
      paymentLink: null,
      msg: "Server Error",
    });
  }
});

module.exports = router;
