const express = require("express");
const create = require("../tools/deposit/create");

const { PrismaClient } = require("@prisma/client");
const prisma = new PrismaClient();

const router = express.Router();
const bcrypt = require("bcrypt");

router.post("/create-order/:pub_KEY", async (req, res) => {
  const pub_KEY = req.params.pub_KEY;
  const { amountUSD, MetaData } = req.body;
  const authHeader = req.headers["authorization"];
  const pri_KEY = authHeader.split(" ")[1];

  const merchant = await prisma.merchant.findFirst({
    where: { pub_KEY, verified: true, accepted: true },
  });

  if (!merchant)
    return res.json({
      success: false,
      message: "no merchant verified and accepted found",
    });

  const auth = await bcrypt.compare(pri_KEY, merchant.pri_KEY);
  if (!auth)
    return res.status(401).json({
      success: false,
      message: "Refresh And Try Again !",
    });

  try {
    const data = await create({
      amountUSD,
      Data: MetaData,
      pub_KEY,
      JWT_KEY: merchant.jwt_KEY,
      merchant,
    });
    return res.json(data);
  } catch (error) {
    console.log(error);
    return res.json({ success: false, error: "server error" });
  }
});

module.exports = router;
