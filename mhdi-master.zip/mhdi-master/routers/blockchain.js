const express = require("express");

const verifyToken = require("../tools/jwt/verifyToken");

const getWallet = require("../tools/wallet/getWallet");
const validate = require("../tools/blockchain/validateTX");

const { PrismaClient } = require("@prisma/client");
const generateToken = require("../tools/jwt/generateToken");
const jwt = require("jsonwebtoken");
const prisma = new PrismaClient();

const router = express.Router();

const path = require("path");
const getPersonalWallet = require("../tools/wallet/getPersonalWallet");
require("dotenv").config({ path: path.resolve(__dirname, "../../.env") });
const SECRET_KEY = process.env.SECRET_KEY;

router.post("/getWallet", async (req, res) => {
  const { encodedCoin, pub_KEY } = req.body;

  try {
    const coin = jwt.verify(encodedCoin, SECRET_KEY);
    if (!coin) res.json({ success: false, message: "Refresh And Try Again !" });

    const merchant = await prisma.merchant.findFirst({ where: { pub_KEY } });
    const { userId } = merchant;
    const result = await getWallet(coin, userId);
    const pub = result.pub;
    if (!pub)
      return res.json({ success: false, message: "error getting the wallet" });
    res.json(result);
  } catch (error) {
    console.log(error);
    return res.json({ success: false, message: "error getting the wallet" });
  }
});

router.post("/getDepositWallet", async (req, res) => {
  const { encoded } = req.body;

  const data = jwt.verify(encoded, SECRET_KEY);
  if (!data) res.json({ success: false, message: "Refresh And Try Again !" });
  const { WalletType, userId } = data;

  const result = await getPersonalWallet(WalletType, userId);
  const pub = result.pub;
  if (!pub)
    return res.json({ success: false, message: "error getting the wallet" });
  res.json(result);
});

router.get("/validateTX", async (req, res) => {
  await validate();

  res.send("validating...");
});

module.exports = router;
