const express = require("express");
const verifyToken = require("../tools/jwt/verifyToken");
const send = require("../tools/email/send");
const {
  UserCryptoOrderCreated,
  MerchantCryptoOrderCreated,
} = require("../tools/email/templates");
const router = express.Router();

router.post("/send-after-crypto-order-created", async (req, res) => {
  const { encodedData } = req.body;

  const data = verifyToken(encodedData);
  if (!data)
    return res
      .status(401)
      .json({ success: false, message: "Refresh And Try Again !" });

  const { email, pub_KEY, amountUSD, amountOfCoin, coin } = data;

  send(
    email,
    "Crypto Order Created",
    UserCryptoOrderCreated(amountUSD, amountOfCoin, coin.name)
  );
  send(
    "email",
    "Crypto Order Created",
    MerchantCryptoOrderCreated(amountUSD, amountOfCoin, coin.name)
  );

  return res.json({ success: true });
});

module.exports = router;
