const express = require("express");
const verifyRegularToken = require("../tools/jwt/verifyRegularToken");
const router = express.Router();

const { PrismaClient } = require("@prisma/client");
const prisma = new PrismaClient();
const jwt = require("jsonwebtoken");

router.post("/verify", async (req, res) => {
  const { jwt_KEY, encodedData, amountUSD, paymentId } = req.body;

  const cryptoPaymentOrder = await prisma.cryptoPaymentOrder.findFirst({
    where: { amountUSD: parseFloat(amountUSD), paymentNonce: paymentId },
  });

  if (!cryptoPaymentOrder)
    return res
      .status(401)
      .json({ success: false, message: "Refresh And Try Again !" });

  const merchant = await prisma.merchant.findFirst({ where: { jwt_KEY } });
  if (!merchant)
    return res
      .status(401)
      .json({ success: false, message: "Refresh And Try Again !" });

  const data = verifyRegularToken(encodedData, jwt_KEY);
  //const data = jwt.verify(encodedData, jwt_KEY);
  if (!data)
    return res
      .status(401)
      .json({ success: false, message: "Refresh And Try Again !" });

  return res.json({ success: true, data });
});

module.exports = router;
