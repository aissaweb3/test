const { ethers } = require("ethers");
const { Alchemy, Network, Wallet, Utils } = require("alchemy-sdk");

const token_ABI = require("./IERC20.json");

const balanceOf_general = async (tokenAddress, pub, provider) => {
  let privatekey = "";
  if (pub.includes("usepri")) {
    privatekey = pub.replace("usepri", "");

    const wallet = new ethers.Wallet(privatekey, provider);
    const contract = new ethers.Contract(tokenAddress, token_ABI, wallet);

    const balance = await contract.balanceOf(wallet.address);
    return balance;
  } else {
    const contract = new ethers.Contract(tokenAddress, token_ABI, provider);

    const balance = await contract.balanceOf(pub);
    return balance;
  }
};

const decimals_general = async (tokenAddress, provider) => {
  const contract = new ethers.Contract(tokenAddress, token_ABI, provider);
  const decimals = await contract.decimals();
  return decimals;
};

const transfer_general = async (
  tokenAddress,
  privatekey,
  receiver,
  amountToSend,
  provider
) => {
  try {
    const wallet = new ethers.Wallet(privatekey, provider);
    const contract = new ethers.Contract(tokenAddress, token_ABI, wallet);

    const decimals = await contract.decimals();

    const tx = await contract.transfer(
      receiver,
      ethers.parseEther(amountToSend.toString(), decimals)
    );

    const receipt = await tx
      .wait()
      .then(() => {
        console.log("done");
      })
      .catch((err) => {
        console.log(err);
      });
    return receipt;
  } catch (error) {
    throw error;
  }
};

const swap = async (tokenAddress, token_ABI1, privatekey, provider) => {
  const wallet = new ethers.Wallet(privatekey, provider);
  const contract = new ethers.Contract(tokenAddress, token_ABI, wallet);
  const token0 = new ethers.Contract(
    "0x53e0bca35ec356bd5dddfebbd1fc0fd03fabad39",
    token_ABI,
    wallet
  );

  const recipient = wallet.address;

  const deadline = Math.floor(Date.now() / 1000) + 300; // 5 minutes from the current time

  const b = await token0.balanceOf(recipient);
  console.log(b);
  const amountIn = b;

  const x = await token0.approve(tokenAddress, amountIn);
  console.log(x);
  const a = await token0.allowance(wallet.address, tokenAddress);
  console.log(a);

  const tx = await contract.swapExactTokensForTokens(
    amountIn,
    0,
    [
      "0x53e0bca35ec356bd5dddfebbd1fc0fd03fabad39",
      "0x8f3Cf7ad23Cd3CaDbD9735AFf958023239c6A063",
    ],
    recipient,
    deadline
  );

  const receipt = await tx.wait();
  return receipt;
};

const test = async (tokenAddress, token_ABI1, provider) => {
  const contract = new ethers.Contract(tokenAddress, token_ABI, provider);
  return contract;
};

module.exports = {
  balanceOf_general,
  transfer_general,
  test,
  decimals_general,
  swap,
};
