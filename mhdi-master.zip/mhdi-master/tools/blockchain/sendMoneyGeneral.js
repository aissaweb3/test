const getPubOfPri = require("../wallet/getPubOfPri");
const general = require("./general");
const getGasFeeNow = require("./getGasFeeNow");

// arbitrum
// ethereum
// optimism
// polygon
// tron

const sendMoney_general = async (pri, coin, amountOfCoin, to, userBalance) => {
  const { isMain, network_dir, smartContract, coinNonce } = coin;

  try {
    if (isMain) {
      // coin
      const sendMoney = require(`./${network_dir}/sendMoney.cjs`);
      const gas = await getGasFeeNow(coinNonce);
      const result = await sendMoney(pri, amountOfCoin, to, userBalance, gas);
      return result;
    } else {
      // token
      const provider = require(`./${network_dir}/provider`);
      try {
        const from = getPubOfPri(pri);
        const receipt = await general.transfer_general(
          smartContract,
          pri,
          to,
          amountOfCoin,
          provider
        );
        console.log("tx:", receipt);
        return { success: true, hash: receipt.hash, from, to };
      } catch (err) {
        console.error("Transfer error:", err);
        return { success: false, error: err.message };
      }
    }
  } catch (error) {
    console.error(error);
    return { success: false };
  }
};
/*
const main = async () => {
  const result = sendMoney_general(
    "b30c0976914b61e0638c7e8bcbfdbcbaca3deb498115b5af239c4fe7409e6288",
    "DupQFez78k",
    0,
    ""
  );
  console.log(result);
};
main();*/

module.exports = sendMoney_general;
