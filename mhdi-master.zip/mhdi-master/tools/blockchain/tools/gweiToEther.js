const { ethers } = require("ethers");

function gweiToEther(gwei) {
  console.log(ethers.formatUnits(gwei, "gwei"));
  return ethers.toBeHex(parseInt(gwei) + 1);

  //return weiAmount;
}
module.exports = gweiToEther;
