const axios = require("axios");
const { API_KEY_TOKEN_POLYGON } = process.env;

const getGasFeeNow = async () => {
  try {
    const response = await axios.get(`https://api.polygonscan.com/api`, {
      params: {
        module: "gastracker",
        action: "gasoracle",
        apikey: API_KEY_TOKEN_POLYGON,
      },
    });
    if (!response.data) return console.log("response error");
    if (response.data.message !== "OK") return console.log(response.data);

    return response.data.result.FastGasPrice;
  } catch (error) {
    throw error;
  }
};
module.exports = getGasFeeNow;
