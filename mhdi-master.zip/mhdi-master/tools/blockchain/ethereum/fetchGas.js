const axios = require("axios");
const blockchain_api_scan_endpoint = require("./data/blockchain_api_scan_endpoint");
const blockchain_api_scan_token = require("./data/blockchain_api_scan_token");

const fetchGas = async () => {
  try {
    const response = await axios.get(blockchain_api_scan_endpoint, {
      params: {
        module: "gastracker",
        action: "gasoracle",
        apikey: blockchain_api_scan_token,
      },
    });
    if (!response.data) return console.log("response error");
    if (response.data.message !== "OK")
      return console.log("got this : ", response.data);

    const gasAsMoney =
      (response.data.result.FastGasPrice + 1) * 10 ** -9 * 21_000;
    return gasAsMoney;
  } catch (error) {
    throw error;
  }
};
module.exports = fetchGas;
