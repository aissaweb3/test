const axios = require("axios");
const blockchain_api_scan_token = require("./data/blockchain_api_scan_token");
const blockchain_api_scan_endpoint = require("./data/blockchain_api_scan_endpoint");

const fetchBalance = async (pub) => {
  try {
    const response = await axios.get(blockchain_api_scan_endpoint, {
      params: {
        module: "account",
        action: "balance",
        address: pub,
        tag: "latest",
        apikey: blockchain_api_scan_token,
      },
    });
    if (!response.data) return console.log("response error");
    if (response.data.message !== "OK") return console.log(response.data);

    return response.data.result;
  } catch (error) {
    throw error;
  }
};

module.exports = fetchBalance;
