const Web3 = require("web3");

// Replace with your Alchemy API key and endpoint
const alchemyApiKey = "YOUR_ALCHEMY_API_KEY";
const alchemyEndpoint = `https://eth-mainnet.alchemyapi.io/v2/${alchemyApiKey}`;

const web3 = new Web3(new Web3.providers.HttpProvider(alchemyEndpoint));

// Replace with your private key
const privateKey = "YOUR_PRIVATE_KEY";

// Fetch current gas price
web3.eth
  .getGasPrice()
  .then((gasPrice) => {
    console.log(
      `Current gas price: ${web3.utils.fromWei(gasPrice, "gwei")} Gwei`
    );

    // Define the transaction
    const tx = {
      to: "0xRecipientAddress...", // Replace with the recipient's address
      value: web3.utils.toWei("0.1", "ether"), // Amount to send in Ether
      gas: 21000, // Gas limit for a simple transfer
      gasPrice: gasPrice, // Current gas price
    };

    // Sign the transaction
    web3.eth.accounts.signTransaction(tx, privateKey).then((signedTx) => {
      // Send the signed transaction
      web3.eth
        .sendSignedTransaction(signedTx.rawTransaction)
        .on("receipt", console.log)
        .on("error", console.error);
    });
  })
  .catch((error) => console.error("Error fetching gas price:", error));
