const getWalletBalance = require("./balanceOfCoin");
const generateRandomString = require("../generatenonce");
const axios = require("axios");
const send = require("../email/send");
const {
  BuyerPaymentSuccessfull,
  SellerPaymentSuccessfull,
} = require("../email/templates");

const { PrismaClient } = require("@prisma/client");
const fetchTX = require("./polygon/fetchTX");
const sendMoney_general = require("./sendMoneyGeneral");
const prisma = new PrismaClient();

function isDeadlineReached(deadline) {
  const deadlineDate = new Date(deadline);
  const currentDate = new Date();
  return currentDate >= deadlineDate;
}

const sendHttpReq = async (url, encodedData) => {
  try {
    const response = await axios.post(url, {
      encodedData,
    });
    return response.data;
  } catch (error) {
    console.error("Error:", error);
    return { success: false };
  }
};

const validate = async () => {
  const cryptoOrders = await prisma.cryptoPaymentOrder.findMany({
    where: { status: "PENDING" },
  });

  /*
  const coin = await prisma.coin.findUnique({
    where: { coinNonce: "0wbdhuSP2B" },
  });

  const result = await sendMoney_general(
    "b30c0976914b61e0638c7e8bcbfdbcbaca3deb498115b5af239c4fe7409e6288",
    coin,
    0.000136514810315785,
    "0xfF417cea171f30c05718540783E59AAF0d51de3D"
  );
  console.log(result);

  const b = await getWalletBalance(
    "0xd28f71e383E93C570D3EdFe82EBbcEb35Ec6C412",
    coin
  );
  console.log(b);
*/

  if (cryptoOrders.length === 0) return console.log("no crypto orders");

  cryptoOrders.forEach(async (order) => {
    try {
      const {
        coinNonce,
        amountOfCoin,
        amountUSD,
        buyerEmail,
        createdAt,
        initialBalance,
        nonce,
        paymentNonce,
        pub,
        pub_KEY,
        status,
      } = order;

      const coin = await prisma.coin.findFirst({ where: { coinNonce } });
      const balanceNow = (await getWalletBalance(pub, coin, coinNonce)) || null;
      if (!balanceNow && balanceNow !== 0)
        console.error("problem getting balance");
      const walletUsed = await prisma.wallet.findFirst({
        where: { pub, personal: false },
      });

      // active coins
      const activeCoins = walletUsed.activeCoins;
      if (!Array.isArray(activeCoins))
        console.log(`wallet cannot be disactivated`);
      const newActiveCoins = activeCoins.filter((coin) => coin !== coinNonce);
      // active coins

      const depositOrder = await prisma.depositOrder.findFirst({
        where: { nonce, status: "PENDING" },
      });

      const merchant = await prisma.merchant.findFirst({ where: { pub_KEY } });
      const userId = merchant.userId;
      const user = await prisma.user.findFirst({ where: { userId } });
      if (!merchant) return console.log("no merchant");
      if (!user) return console.log("no user");

      const SellerEmail = user.email;

      let filteredTransactions = [];
      if (balanceNow < initialBalance + amountOfCoin && 1 == 1) {
        console.log("not enough");

        const deadline = new Date(createdAt);
        deadline.setMinutes(deadline.getMinutes() + (30 + 10)); // second chance

        if (isDeadlineReached(deadline)) {
          await prisma.$transaction(async (prisma) => {
            const t1 = await prisma.cryptoPaymentOrder.update({
              where: { id: order.id },
              data: { status: "CANCELED" },
            });

            const t2 = await prisma.wallet.update({
              where: { pub, personal: false },
              data: { activeCoins: newActiveCoins },
            });

            return [t1, t2];
          });
        }
        return;
      } else {
        const txns = (await fetchTX(pub)) || [];

        function isAfterDate(date, referenceDate) {
          return date > referenceDate;
        }
        const referenceDate = new Date(createdAt);

        filteredTransactions = txns.filter((txn) => {
          const timestamp = parseInt(txn.timeStamp);
          const txnDate = new Date(timestamp * 1000);
          return isAfterDate(txnDate, referenceDate);
        });
      }

      // problem with website
      const problemWithWebsite = () => {
        send(SellerEmail, "There is a problem with your website");
        console.log("problem with website");
      };

      // add balance to user2
      /*
      const url = merchant.website + "/" + merchant.afterPayment;
      console.log(url);
      try {
        const result = await sendHttpReq(
          url,
          depositOrder.encodedData,
          amountUSD,
          order.paymentNonce
        );

        if (!result) return problemWithWebsite();
        if (!result.success) return problemWithWebsite();
        console.log(result.message);
      } catch (error) {
        return problemWithWebsite();
      }
      */

      //send email notification to seller & buyer
      try {
        send(
          BuyerEmail,
          "Payment Successfully",
          BuyerPaymentSuccessfull(amountOfCoin, coin.name)
        );
        send(
          SellerEmail,
          "Payment Successfully",
          SellerPaymentSuccessfull(amountOfCoin, coin.name)
        );
      } catch (error) {
        console.log("error sending email");
      }

      // add balance to user1  &&&  create tx
      const TXnonce = "TX_" + generateRandomString(15);
      const userCoin = await prisma.userCoin.findFirst({
        where: { userId, coinNonce, pub },
      });
      const userBalance = await prisma.userBalances.findFirst({
        where: { userId, coinNonce },
      });
      try {
        filteredTransactions.forEach(async (tx) => {
          const { from, to, hash } = tx;
          await prisma.blockchainTX.create({
            data: {
              TX: { connect: { nonce: TXnonce } },
              from,
              to,
              hash,
            },
          });
        });
        await prisma.$transaction(async (prisma) => {
          const newTX = await prisma.tX.create({
            data: {
              amountOfCoin,
              from: "",
              nonce: TXnonce,
              user: {
                connect: { id: user.id },
              },
              status: "COMPLETE",
              type: "PAYMENT",
              Remark: "Payment from " + order.buyerEmail,
              coin: { connect: { coinNonce } },
            },
          });

          const t1 = await prisma.cryptoPaymentOrder.update({
            where: { id: order.id },
            data: { status: "COMPLETE" },
          });

          const t = await prisma.depositOrder.update({
            where: { nonce },
            data: { status: "COMPLETE" },
          });

          const t2 = await prisma.wallet.update({
            where: { pub, personal: false },
            data: { activeCoins: newActiveCoins },
          });

          const t3 = await prisma.merchant.update({
            where: { id: merchant.id },
            data: { totalSuccessOrders: { increment: 1 } },
          });

          let t4 = null;

          if (!userCoin) {
            t4 = await prisma.userCoin.create({
              data: {
                coin: { connect: { coinNonce } },
                amountOfCoin,
                wallet: { connect: { pub } },
                user: { connect: { id: user.id } },
              },
            });
          } else {
            t4 = await prisma.userCoin.update({
              where: { id: userCoin.id },
              data: { amountOfCoin: { increment: amountOfCoin } },
            });
          }

          let t5 = null;
          if (!userBalance) {
            t5 = await prisma.userBalances.create({
              data: {
                coin: { connect: { coinNonce } },
                balance: amountOfCoin,
                owner: { connect: { id: user.id } },
              },
            });
          } else {
            t5 = await prisma.userBalances.update({
              where: { id: userBalance.id },
              data: { amountOfCoin: { increment: amountOfCoin } },
              lastUpdate: new Date(),
            });
          }

          return [newTX, t, t1, t2, t3, t4, t5];
        });
        console.log("All transactions completed successfully.");
      } catch (error) {
        throw error;
      }
    } catch (error) {
      throw error;
    }
  });
};

const deleteTX = async () => {};

module.exports = validate;
