const { PrismaClient } = require("@prisma/client");
const { balanceOf_general } = require("./general");

const getWalletBalance = async (pub, coin, coinNonce) => {
  const prisma = new PrismaClient();
  if (!coin) coin = await prisma.coin.findUnique({ where: { coinNonce } });
  if (!coin) return null;
  const { isMain, network_dir, smartContract, decimals } = coin;

  try {
    if (isMain) {
      // coin
      const fetchBalance = require(`./${network_dir}/fetchBalance.js`);
      let balance = await fetchBalance(pub);
      if (balance)
        balance = parseInt(balance.toString()) * Math.pow(10, -decimals);

      return balance;
    } else {
      // token

      const provider = require(`./${network_dir}/provider.js`);
      let balance = await balanceOf_general(smartContract, pub, provider);
      if (balance)
        balance = parseInt(balance.toString()) * Math.pow(10, -decimals);
      return balance;
    }
  } catch (error) {
    console.log(error);
  }
};

const main = async (pub, coin, coinNonce) => {
  const b = await getWalletBalance(pub, coin, coinNonce);
  console.log(b);
};
//main("0x4b3d65Eef31049B88f1A258666BeE56Abf77d53C", null, "4cazSBBBWY");

module.exports = getWalletBalance;
