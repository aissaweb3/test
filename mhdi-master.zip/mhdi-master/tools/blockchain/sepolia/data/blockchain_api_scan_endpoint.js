const blockchain_api_scan_endpoint = `https://api-sepolia.etherscan.io/api`;
module.exports = blockchain_api_scan_endpoint;
