const path = require("path");
require("dotenv").config({ path: path.resolve(__dirname, "../../../../.env") });
const { ALCHEMY_PROVIDER_TOKEN_SEPOLIA } = process.env;

const provider_alchemy = ALCHEMY_PROVIDER_TOKEN_SEPOLIA;
https: module.exports = provider_alchemy;
