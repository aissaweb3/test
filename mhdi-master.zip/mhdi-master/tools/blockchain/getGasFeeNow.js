const path = require("path");
require("dotenv").config({ path: path.resolve(__dirname, "../../.env") });
const { PrismaClient } = require("@prisma/client");
const { Utils } = require("alchemy-sdk");
const gweiToEther = require("./tools/gweiToEther");
const prisma = new PrismaClient();

const getGasFeeNow = async (coinNonce) => {
  const gas = await prisma.gas.findFirst({ where: { coinNonce } });
  if (!gas) return null;

  return gas.gasFeeNow;

  /*try {
    const response = await axios.get(`https://api.polygonscan.com/api`, {
      params: {
        module: "gastracker",
        action: "gasoracle",
        apikey: API_KEY_TOKEN_POLYGON,
      },
    });
    if (!response.data) return console.log("response error");
    if (response.data.message !== "OK") return console.log(response.data);

    return {
      worst: response.data.result.SafeGasPrice,
      best: response.data.result.FastGasPrice,
    };
  } catch (error) {
    throw error;
  }*/
};

module.exports = getGasFeeNow;
