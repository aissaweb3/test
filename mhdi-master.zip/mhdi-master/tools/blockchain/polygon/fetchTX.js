const axios = require("axios");
const blockchain_api_scan_endpoint = require("./data/blockchain_api_scan_endpoint");
const blockchain_api_scan_token = require("../ethereum/data/blockchain_api_scan_token");

const fetchTX = async (pub) => {
  try {
    const response = await axios.get(blockchain_api_scan_endpoint, {
      params: {
        module: "account",
        action: "txlist",
        address: pub,
        apikey: blockchain_api_scan_token,
      },
    });
    if (!response.data) return console.log("response error");
    if (response.data.message !== "OK") return console.log(response.data);

    return response.data.result;
  } catch (error) {
    throw error;
  }
};

module.exports = fetchTX;
