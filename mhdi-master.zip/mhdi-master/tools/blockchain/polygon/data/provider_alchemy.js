const path = require("path");
require("dotenv").config({ path: path.resolve(__dirname, "../../../../.env") });
const { ALCHEMY_PROVIDER_TOKEN_POLYGON } = process.env;

const provider_alchemy = ALCHEMY_PROVIDER_TOKEN_POLYGON;
module.exports = provider_alchemy;
