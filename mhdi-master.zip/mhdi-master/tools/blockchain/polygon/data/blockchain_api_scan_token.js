const path = require("path");
require("dotenv").config({ path: path.resolve(__dirname, "../../../../.env") });
const { API_KEY_TOKEN_POLYGON } = process.env;

const blockchain_api_scan_token = API_KEY_TOKEN_POLYGON;
module.exports = blockchain_api_scan_token;
