const { Alchemy, Network, Wallet, Utils } = require("alchemy-sdk");
const decrypt = require("../../crypto/decrypt");
const { ethers } = require("ethers");
const fetchBalance = require("./fetchBalance");
const provider_alchemy = require("./data/provider_alchemy");

const settings = {
  apiKey: provider_alchemy,
  network: Network.MATIC_MAINNET,
};
const alchemy = new Alchemy(settings);

async function sendMoney(pri, amountOfCoin, to, userBalance, gas) {
  try {
    console.log("sending money...");

    const gasLimit = 21000;
    const gasfee = gas;

    const value =
      amountOfCoin + gasfee > userBalance
        ? userBalance - gasfee
        : amountOfCoin + gasfee;

    //console.log({ gasfee, value, userBalance });

    // Ensure the calculated value is positive
    if (value < 0) {
      console.error("Insufficient funds to cover gas fee");
      return {
        success: false,
        error: "Insufficient funds to cover gas fee",
      };
    }

    const PRIVATE_KEY = decrypt(pri).replace("0x", "");

    let wallet = new Wallet(PRIVATE_KEY);
    const walletBalance = await fetchBalance(wallet.address);
    if (walletBalance < value) {
      console.error("Insufficient balance");
      return {
        success: false,
        error: "Insufficient balance",
      };
    }

    try {
      const nonce = await alchemy.core.getTransactionCount(
        wallet.address,
        "latest"
      );

      console.log(value);

      let transaction = {
        to,
        value: Utils.parseEther(value.toString()),
        gasLimit,
        maxPriorityFeePerGas: Utils.parseUnits(
          ((gas * 10 ** 9) / 21000).toString(),
          "gwei"
        ),
        maxFeePerGas: Utils.parseUnits(
          ((gas * 10 ** 9) / 21000).toString(),
          "gwei"
        ),
        nonce: nonce,
        type: 2,
        chainId: 137,
      };

      let rawTransaction = await wallet.signTransaction(transaction);
      let tx = await alchemy.core.sendTransaction(rawTransaction);
      console.log("Sent transaction", tx);
      console.log("done.");

      return {
        success: true,
        hash: tx.hash,
        from: tx.from,
        to: tx.to,
      };
    } catch (error) {
      console.log(error);
      return {
        success: false,
        error,
      };
    }
  } catch (error) {
    console.log(error);
    return {
      success: false,
      error,
    };
  }
}

const main = async () => {
  const result = await sendMoney(
    "private key",
    1,
    "0xfF417cea171f30c05718540783E59AAF0d51de3D",
    1,
    31 * 10 ** -9
  );
  console.log(result);
};

//main();

module.exports = sendMoney;
