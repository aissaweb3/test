const { ethers } = require("ethers");
const provider_infura = require("./data/provider_infura");
const provider_alchemy = require("./data/provider_alchemy");

const network = "matic";
const alchemyApiKey = provider_alchemy;
const infureApiKey = provider_infura;

const provider = ethers.getDefaultProvider(network, {
  //alchemy: alchemyApiKey,
  infura: infureApiKey,
});

module.exports = provider;
