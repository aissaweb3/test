const { balanceOf_general } = require("../general.js");

const fetchBalance = async (pub) => {
  const smartContract = "0x0000000000000000000000000000000000001010";
  const provider = require(`./provider.js`);
  const balance = await balanceOf_general(smartContract, pub, provider);
  return balance;
};

module.exports = fetchBalance;
