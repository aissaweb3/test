const { PrismaClient } = require("@prisma/client");
const prisma = new PrismaClient();
const getWalletBalance = require("../blockchain/balanceOfCoin");

const generateWallet = async (userId, coinNonce, WalletType) => {
  const generateEVM = require(`../../tools/wallet/${WalletType}/generateWallet`);
  const { pri, pub } = await generateEVM();

  const firstUser = await prisma.user.findUnique({ where: { userId } });
  await prisma.wallet.create({
    data: {
      ownedBy: {
        connect: [{ userId: firstUser.userId }],
      },
      pub,
      pri,
      WalletType,
      personal: false,
      activeCoins: [coinNonce],
    },
  });

  return pub;
};

const getWallet = async (coin, userId) => {
  try {
    const { coinNonce, WalletType } = coin;

    let wallets = await prisma.wallet.findMany({
      where: {
        ownedBy: {
          some: {
            userId: userId,
          },
        },
        personal: false,
      },
    });

    let wallet = wallets.filter(
      (wallet) => !wallet.activeCoins.includes(coinNonce)
    )[0];

    let pub = "";

    if (wallet) {
      pub = wallet.pub;

      let activeCoinsPlus = [];
      wallet.activeCoins.forEach((coinNonce) => {
        activeCoinsPlus.push(coinNonce);
      });
      activeCoinsPlus.push(coinNonce);

      await prisma.wallet.update({
        where: { id: wallet.id, personal: false },
        data: { activeCoins: activeCoinsPlus },
      });

      const initialBalance = await getWalletBalance(pub, coin, coinNonce);
      return { success: true, pub, initialBalance };
    }
    if (!wallet) pub = await generateWallet(userId, coinNonce, WalletType);
    const initialBalance = 0;
    return { success: true, pub, initialBalance };
  } catch (error) {
    console.log(error);
    return { success: false, error: "can't get wallet" };
  }
};

module.exports = getWallet;
