const disable = async () => {
  const wallets = await DepositWallet.find({ active: true });

  if (!wallets) return;

  const now = new Date();

  wallets.forEach((wallet) => {
    const deadline = wallet.when;
    deadline.setMinutes(deadline.getMinutes() + 30);

    if (deadline <= now) {
      wallet.active = false;
      wallet.save().then((wallett) => {
        console.log(wallett);
      });
    }
  });
};

module.exports = disable;
