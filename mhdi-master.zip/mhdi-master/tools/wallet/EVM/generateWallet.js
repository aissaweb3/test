var Wallet = require("ethereumjs-wallet");
const encrypt = require("../../crypto/encrypt");

const generate = async () => {
  const EthWallet = Wallet.default.generate();
  const pri = encrypt(EthWallet.getPrivateKeyString());
  const data = {
    pub: EthWallet.getAddressString(),
    pri,
  };
  return data;
};

module.exports = generate;
