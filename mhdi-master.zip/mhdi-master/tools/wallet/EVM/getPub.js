const { Wallet } = require("alchemy-sdk");

const getPub = async (pri) => {
  let wallet = new Wallet(pri);
  return wallet.address;
};
module.exports = getPub;
