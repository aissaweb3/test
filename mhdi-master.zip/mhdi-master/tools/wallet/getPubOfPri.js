const getPubOfPri = async (pri, type) => {
  const getPub = require(`./${type}/getPub`);
  const pub = await getPub(pri);
  return pub;
};
module.exports = getPubOfPri;
