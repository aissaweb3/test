const { PrismaClient } = require("@prisma/client");
const prisma = new PrismaClient();

const generateWallet = async (userId, WalletType) => {
  const generate = require(`../../tools/wallet/${WalletType}/generateWallet`);
  const { pri, pub } = await generate();

  const onlyUser = await prisma.user.findUnique({ where: { userId } });
  await prisma.wallet.create({
    data: {
      ownedBy: {
        connect: [{ userId: onlyUser.userId }],
      },
      pub,
      pri,
      WalletType,
      personal: true,
      activeCoins: [],
    },
  });

  return pub;
};

const getPersonalWallet = async (WalletType, userId) => {
  try {
    let wallet = await prisma.wallet.findFirst({
      where: {
        ownedBy: {
          some: {
            userId: userId,
          },
        },
        WalletType,
        personal: true,
      },
    });

    let pub = "";

    if (wallet) {
      pub = wallet.pub;
      return { success: true, pub };
    }
    if (!wallet) pub = await generateWallet(userId, WalletType);
    return { success: true, pub };
  } catch (error) {
    console.log(error);
    return { success: false, error: "can't get wallet" };
  }
};

module.exports = getPersonalWallet;
