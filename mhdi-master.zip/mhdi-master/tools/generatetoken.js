
const axios = require('axios')
require('dotenv').config();

const youcanpay = process.env.YCP_SERVER || 'https://smmgoo.com/youcanpay'

const generatePaymentToken = async (amount, orderid) => {
  try {
    // Make a request to your backend to generate the payment token
    const response = await axios.post(
      `${youcanpay}/create.php?amount=${amount*100}&orderid=${orderid}`
    );
    return response.data.tokenId;
  } catch (error) {
    console.error("Error generating payment token:", error);
  }
};
module.exports = generatePaymentToken;
