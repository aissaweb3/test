const crypto = require("crypto");

function decrypt(encryptedText) {
  const decipher = crypto.createDecipher("aes-256-cbc", "YourSecretKey");
  let decrypted = decipher.update(encryptedText, "hex", "utf8");
  decrypted += decipher.final("utf8");
  console.log("decrypting...");
  return decrypted;
}

module.exports = decrypt;
