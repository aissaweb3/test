const { Alchemy, Network, Wallet, Utils } = require("alchemy-sdk");
const dotenv = require("dotenv");
const decrypt = require("../crypto/decrypt");
const getGasFeeNow = require("../blockchain/getGasFeeNow");

dotenv.config();
const API_KEY = "Fkhrqq6FnqtaSk2RsFO-J432v1VFl4Px";
//const PRIVATE_KEY = "423cd3039e4d17f039d6362ee3a12c69bc32c2e082bc7a5e4ece1d9d84d0977e";

const settings = {
  apiKey: API_KEY,
  network: Network.MATIC_MAINNET,
};
const alchemy = new Alchemy(settings);

async function sendMoney(pri, network, coin, amountOfCoin, to) {
  const gasfee = await getGasFeeNow();

  const gasFeeWei = Utils.parseUnits(gasfee.worst, "gwei");
  const value = Utils.parseEther(amountOfCoin.toString()).sub(gasFeeWei);

  // Ensure the calculated value is positive
  if (value < 0) {
    return {
      success: false,
      error: "Insufficient funds to cover gas fee",
    };
  }

  try {
    const PRIVATE_KEY = decrypt(pri).replace("0x", "");

    let wallet = new Wallet(PRIVATE_KEY);
    const nonce = await alchemy.core.getTransactionCount(
      wallet.address,
      "latest"
    );

    let transaction = {
      to,
      value,
      gasLimit: "21000",
      maxPriorityFeePerGas: gasFeeWei,
      maxFeePerGas: gasFeeWei,
      nonce: nonce,
      type: 2,
      chainId: 137,
    };

    let rawTransaction = await wallet.signTransaction(transaction);
    let tx = await alchemy.core.sendTransaction(rawTransaction);
    console.log("Sent transaction", tx);

    return {
      success: true,
      hash: tx.hash,
    };
  } catch (error) {
    return {
      success: false,
      error,
    };
  }
}

module.exports = sendMoney;
