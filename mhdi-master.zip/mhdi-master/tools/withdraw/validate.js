const { PrismaClient } = require("@prisma/client");
const sendMoney_general = require("../blockchain/sendMoneyGeneral");
const decrypt = require("../crypto/decrypt");
const getWalletBalance = require("../blockchain/balanceOfCoin");
const getGasFeeNow = require("../blockchain/getGasFeeNow");
const getPubOfPri = require("../wallet/getPubOfPri");
const prisma = new PrismaClient();

const CancelAll = async (Remark, preOrder) => {
  const { userId, coinNonce, id, amountOfCoin } = preOrder;
  await prisma.$transaction(async (prisma) => {
    const t1 = await prisma.withdrawOrder.updateMany({
      where: { preOrderId: id },
      data: { status: "CANCELED" },
    });
    const t2 = await prisma.withdrawPreOrder.update({
      where: { id },
      data: { status: "CANCELED" },
    });

    const t3 = await prisma.tX.updateMany({
      where: { withdrawPreOrder: { id } },
      data: {
        status: "CANCELED",
        Remark,
      },
    });
    const t4 = await prisma.userBalances.updateMany({
      where: {
        userId,
        coinNonce,
      },
      data: { balance: { increment: amountOfCoin } },
    });
    return { t1, t2, t3, t4 };
  });
};

const validateCrypto = async () => {
  /*
  const b = await getWalletBalance(
    "0x283af0b28c62c092c9727f1ee09c02ca627eb7f5",
    null,
    "4cazSBBBWY"
  );
  return console.log(b);*/

  const preOrders = await prisma.withdrawPreOrder.findMany({
    where: { status: "IN_PRPGRESS" },
  });
  preOrders.forEach(async (preOrder) => {
    const orders = await prisma.withdrawOrder.findMany({
      where: { preOrderId: preOrder.id },
    });
    if (orders.length === 0) return console.log("no withdrawal orders");

    let youCanGo = [];

    orders.forEach(async (order) => {
      youCanGo.push(1); // all is good
    });
    for (let i = 0; i < orders.length; i++) {
      const order = orders[i];

      let totalBalance = 0;
      orders.forEach((singleOrder) => {
        totalBalance += singleOrder.amountOfCoin;
      });
      if (totalBalance < preOrder.amountOfCoin) return (youCanGo[i] = 0);

      console.log("checking...");
      const { userId, coinNonce, pri, amountOfCoin } = order;

      const coin = await prisma.coin.findUnique({ where: { coinNonce } });
      if (!coin) return (youCanGo[i] = 0);
      const balance = await getWalletBalance(
        "usepri" + decrypt(pri),
        null,
        coinNonce
      );
      if (balance < amountOfCoin) {
        youCanGo[i] = 0;
      }

      if (coin.isMain === false) {
        const mainCoin = await prisma.coin.findFirst({
          where: { network_dir: coin.network_dir, isMain: true },
        });

        const mainCoinBalance = await fetchBalance(wallet.address);

        const gas = await getGasFeeNow(mainCoin.coinNonce);
        const gasLimit = 21000;
        const gasfee = gas * gasLimit;

        if (mainCoinBalance < gasfee) return (youCanGo[i] = 0);
        // add gas
      }

      const userBalanceOfCoinInThisWallet = await prisma.userCoin.findFirst({
        where: { coinNonce, userId, pub: order.from },
      });
      if (!userBalanceOfCoinInThisWallet) youCanGo[i] = 0;

      console.log("done");
    }
    console.log(youCanGo);
    if (youCanGo.includes(0)) {
      console.log("can't withdraw, canceling...");
      await CancelAll("Not Enough Balance In Wallet, Order Canceled", preOrder);
      return console.log("done");
      //send email
    }

    orders.forEach(async (order) => {
      try {
        console.log("withdrawing...");
        const { userId, coinNonce, pri, amountOfCoin, to } = order;

        const coin = await prisma.coin.findUnique({ where: { coinNonce } });
        let amountToSend = amountOfCoin;

        const userBalanceOfCoinInThisWallet = await prisma.userCoin.findFirst({
          where: { coinNonce, userId, pub: order.from },
        });

        const result = await sendMoney_general(
          pri,
          coin,
          amountToSend,
          to,
          userBalanceOfCoinInThisWallet.amountOfCoin
        );

        if (!result.success)
          return console.error({
            msg: "could not send money",
            error: result.error,
          });

        await prisma.$transaction(async (prisma) => {
          const t1 = await prisma.withdrawOrder.update({
            where: { id: order.id },
            data: { status: "COMPLETE", hash: result.hash },
          });
          const t2 = await prisma.withdrawPreOrder.update({
            where: { id: order.preOrderId },
            data: { status: "COMPLETE" },
          });

          const tx = await prisma.tX.findFirst({
            where: { withdrawPreOrder: { id: order.preOrderId } },
          });

          const t5 = await prisma.tX.update({
            where: { id: tx.id },
            data: {
              status: "COMPLETE",
              Remark: "Your Withdrawal Was Successfull.",
            },
          });

          const t6 = await prisma.blockchainTX.create({
            data: {
              from: result.from,
              hash: result.hash,
              to: result.to,
              TX: { connect: { id: tx.id } },
            },
          });

          const pub = await getPubOfPri(decrypt(pri), coin.WalletType);
          const t3 = await prisma.userCoin.updateMany({
            where: { coinNonce, userId, pub },
            data: { amountOfCoin: { decrement: amountOfCoin } },
          });
          return { t1, t2, t3, t5, t6 };
        });

        return console.log(
          userId,
          "withdrawed",
          amountOfCoin,
          coin.name,
          " sent to ",
          to
        );
      } catch (error) {
        throw error;
      }
    });
  });
};

const createWithdrawOrders = async () => {
  const preOrders = await prisma.withdrawPreOrder.findMany({
    where: { status: "PENDING" },
  });

  if (!preOrders || preOrders.length === 0)
    return console.log("no withdrawal preOrders");

  preOrders.forEach(async (preOrder) => {
    try {
      const { txNonce, coinNonce, amountOfCoin, address } = preOrder;
      const tx = await prisma.tX.findUnique({
        where: {
          nonce: txNonce,
        },
      });

      const userId = tx.userId;

      // user wallets
      const wallets = await prisma.wallet.findMany({
        where: {
          ownedBy: { some: { userId } },
          coins: { some: { coinNonce } },
        },
      });

      const walletsPlus = [];
      const userCoins = await prisma.userCoin.findMany({
        where: { userId, coinNonce },
      });
      await Promise.all(
        wallets.map(async (wallet) => {
          // Assuming userCoins is defined elsewhere
          const walletCoins = userCoins.filter(
            (userCoin) => userCoin.pub === wallet.pub
          );
          const walletWithExtraInfo = {
            ...wallet,
            amountOfCoin: walletCoins[0].amountOfCoin, // Assuming walletCoins[0] always exists
          };
          walletsPlus.push(walletWithExtraInfo);
        })
      );

      walletsPlus.sort((a, b) => b.amountOfCoin - a.amountOfCoin);

      let balanceWeNeed = 0;
      let done = false;
      const walletsWeNeed = [];
      walletsPlus.forEach((wallet, i) => {
        if (balanceWeNeed < amountOfCoin && !done) {
          walletsWeNeed.push(wallet);
        } else {
          done = true;
        }
        balanceWeNeed += wallet.amountOfCoin;
      });

      //console.log(walletsWeNeed, balanceWeNeed);

      await createVerifiedWithdrawOrders(
        walletsWeNeed,
        address,
        coinNonce,
        preOrder,
        userId,
        amountOfCoin
      );
      // create Withdraw Orders
    } catch (error) {
      console.log(error);
    }
  });
};

const createVerifiedWithdrawOrders = async (
  walletsWeNeed,
  to,
  coinNonce,
  preOrder,
  userId,
  amountOfCoin
) => {
  // in progresss
  const { id } = preOrder;
  let miniOrders = [];
  let sent = 0;
  let sentInPast = 0;
  let total = 0;
  walletsWeNeed.forEach(async (walletWeNeed) => {
    total += walletWeNeed.amountOfCoin;
  });

  if (total < amountOfCoin) {
    await CancelAll("Not Enough Balance In Wallet, Order Canceled", preOrder);
    return;
  }

  walletsWeNeed.forEach(async (walletWeNeed) => {
    const { pri, pub } = walletWeNeed;
    sent += walletWeNeed.amountOfCoin; // want 1000  900 230 10

    let amountToSend = 0;
    if (sent <= amountOfCoin) {
      amountToSend = walletWeNeed.amountOfCoin;
    } else {
      amountToSend = amountOfCoin - sentInPast;
    }
    sentInPast += walletWeNeed.amountOfCoin;

    miniOrders.push({
      userId,
      coinNonce,
      from: pub,
      preOrderId: id,
      pri,
      amountOfCoin: amountToSend,
      to,
      hash: "",
    });
  });

  try {
    await prisma.$transaction(async (prisma) => {
      const o1 = await prisma.tX.updateMany({
        where: { withdrawPreOrder: { id } },
        data: { status: "IN_PRPGRESS" },
      });
      const o2 = await prisma.withdrawOrder.createMany({
        data: miniOrders,
      });
      const o3 = await prisma.withdrawPreOrder.update({
        where: { id },
        data: { status: "IN_PRPGRESS" },
      });
      return [o1, o2, o3];
    });
  } catch (error) {
    console.log(error);
  }
};

module.exports = async () => {
  await createWithdrawOrders();
  await validateCrypto();
};
