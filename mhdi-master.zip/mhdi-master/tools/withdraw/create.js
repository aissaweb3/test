const createWithdrawOrder = async (sellOrder, paymentOrder) => {
  const { coin, network } = sellOrder;
  const amountOfCoin = paymentOrder.amountUSD / sellOrder.price;
  const to = paymentOrder.walletPub;
  const from = sellOrder.from;

  const newWithdrawOrder = new withdrawOrder({
    pri: "0x.......",
    network,
    coin,
    amountOfCoin,
    from,
    to,

    hash: "",

    status: "PENDING",

    when: new Date(),
  });

  newWithdrawOrder
    .save()
    .then((saved) => {
      console.log("Withdrawal order...", saved);
    })
    .catch((error) => {
      console.error("Error saving sell order:", error);
      return { success: false };
    });
  return { success: true };
};

module.exports = createWithdrawOrder;
