require('dotenv').config();
const { Alchemy, Network, Utils } = require('alchemy-sdk');

// Optional Config object, but defaults to demo api-key and eth-mainnet.
const settings = {
  apiKey: process.env.ALCHEMY_API_KEY,
  network: Network.ETH_MAINNET,
};

const alchemy = new Alchemy(settings);

async function getCurrentGas() {
  const currentGasInHex = await alchemy.core.getGasPrice();

  console.log(
    'The current gas cost on the network is: ' +
      Utils.formatUnits(currentGasInHex, 'gwei') +
      ' gwei'
  );
}

getCurrentGas();