const { ethers } = require("ethers");
const USDT_ABI = require("./USDT_ABI.json"); // Assuming you have the ABI of the USDT contract

// Use the mainnet
const network = "homestead";
// Specify your own Infura API key
const infuraApiKey = "6d95d1a42fe34cfd96f19ca4b02110b9";

// Create a provider with your API key
const provider = ethers.getDefaultProvider(network, {
  infura: infuraApiKey,
});

// Set up the wallet
const privateKey =
  "b30c0976914b61e0638c7e8bcbfdbcbaca3deb498115b5af239c4fe7409e6288";
const wallet = new ethers.Wallet(privateKey, provider);
// USDT contract address
const usdtAddress = "0xc2132d05d31c914a87c6611c10748aeb04b58e8f";

// Connect to the USDT contract
const usdtContract = new ethers.Contract(usdtAddress, USDT_ABI, wallet);
const erc20 = new ethers.Contract(usdtAddress, USDT_ABI, provider);
// Recipient address
const recipientAddress = "0xfF417cea171f30c05718540783E59AAF0d51de3D";

async function main() {
  // Define the ERC-20 token contract
  const contract = new ethers.Contract(usdtAddress, USDT_ABI, provider);

  // Creating a signing account from a private key
  const signer = new ethers.Wallet(privateKey, provider);

  // Define and parse token amount. Each token has 18 decimal places. In this example we will send 1 LINK token
  const amount = "1.0";

  //Define the data parameter
  const contractSigner = contract.connect(signer);

  //Define tx and transfer token amount to the destination address
  const tx = await contractSigner.transfer(recipientAddress, amount);

  // Waiting for the transaction to be mined
  const receipt = await tx.wait();

  // The transaction is now on chain!
  console.log(`Mined in block ${receipt.blockNumber}`);
}

main();
