const { PrismaClient } = require("@prisma/client");
const prisma = new PrismaClient();

const setGasFeeOfNetworkTo = async () => {
  const mainCoins = await prisma.coin.findMany({ where: { isMain: true } });

  mainCoins.forEach(async (mainCoin) => {
    try {
      const { coinNonce } = mainCoin;
      const getGasFeeNow = require(`../blockchain/${mainCoin.network_dir}/fetchGas`);
      let gasFeeNow = await getGasFeeNow();
      gasFeeNow = parseFloat(gasFeeNow);

      const gas = await prisma.gas.findFirst({ where: { coinNonce } });
      if (gas) {
        await prisma.gas.updateMany({
          where: { coinNonce },
          data: { gasFeeNow },
        });
      } else {
        await prisma.gas.create({
          data: { gasFeeNow, coin: { connect: { coinNonce } } },
        });
      }
    } catch (error) {
      return;
      throw error;
    }
  });

  console.log("gas updated");
};
module.exports = setGasFeeOfNetworkTo;
