const path = require("path");
require("dotenv").config({ path: path.resolve(__dirname, "../../.env") });

const generateRandomString = require("../generatenonce");
const generateRegularToken = require("../jwt/generateRegularToken");
const { PrismaClient } = require("@prisma/client");

const jwt = require("jsonwebtoken");

const create = async (data) => {
  const nonce = generateRandomString(25);
  const { amountUSD, Data, pub_KEY, JWT_KEY, merchant } = data;

  const encodedData = jwt.sign({ clientMetaData: Data, amountUSD }, JWT_KEY, {
    expiresIn: "5h",
  });

  try {
    const prisma = new PrismaClient();

    await prisma.depositOrder.create({
      data: {
        nonce,
        amountUSD,
        merchant: {
          connect: { id: merchant.id },
        },
        encodedData,
      },
    });

    await prisma.merchant.update({
      where: {
        pub_KEY,
      },
      data: { totalOrders: { increment: 1 } },
    });

    return {
      success: true,
      paymentLink: process.env.FRONT_END + "/pay/crypto/" + nonce,
    };
  } catch (error) {
    console.log(error);
    return { success: false, error: "server error" };
  }
};
module.exports = create;
