const cron = require("node-cron");

const validateCrypto = require("./withdraw/validate");
const validateTX = require("./blockchain/validateTX");
const setGasFeeOfNetworkTo = require("./setGasFee/generalSetting");
const setCoinPriceTo = require("./setCoinPrice/generalSetting");

module.exports = {
  validateCrypto,
  validateTX,
  setGasFeeOfNetworkTo,
  setCoinPriceTo,
};

cron.schedule("* * * * *", () => {
  validateCrypto();
  setGasFeeOfNetworkTo();
});

// normally 10 min
cron.schedule("* * * * *", () => {
  validateTX();
});

cron.schedule("*/30 * * * *", () => {
  setCoinPriceTo();
});
