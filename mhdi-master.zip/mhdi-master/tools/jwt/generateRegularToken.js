const jwt = require('jsonwebtoken');

const TOKEN_EXPIRATION = '5h';

const generateRegularToken = (payload, secret) => {
  return jwt.sign(payload, secret, { expiresIn: TOKEN_EXPIRATION });
};

module.exports = generateRegularToken;
