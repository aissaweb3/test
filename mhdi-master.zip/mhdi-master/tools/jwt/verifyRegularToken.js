const jwt = require("jsonwebtoken");

const verifyRegularToken = (token, key) => {
  try {
    const decodedPayload = jwt.verify(token, key);
    return decodedPayload;
  } catch (error) {
    if (error.name === "TokenExpiredError") {
      console.log("Token has expired.");
      return null;
    } else {
      console.log("Invalid token.");
      return null;
    }
  }
};

module.exports = verifyRegularToken;
