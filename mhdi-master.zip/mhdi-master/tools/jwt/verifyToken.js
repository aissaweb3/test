const jwt = require("jsonwebtoken");
const path = require("path");
require("dotenv").config({ path: path.resolve(__dirname, "../../.env") });
const SECRET_KEY = process.env.SECRET_KEY; // Replace with your secret key

const restoreDate = (token) => {
  try {
    return jwt.verify(token, SECRET_KEY);
  } catch (error) {
    if (error.name === "TokenExpiredError") {
      console.log("Token has expired.");
      return null;
    } else {
      console.log("Invalid token.");
      return null;
    }
  }
};

module.exports = restoreDate;
