const jwt = require("jsonwebtoken");
const path = require("path");
require("dotenv").config({ path: path.resolve(__dirname, "../../.env") });
const SECRET_KEY = process.env.SECRET_KEY;

const TOKEN_EXPIRATION = "5h";

const generateToken = (payload) => {
  return jwt.sign(payload, SECRET_KEY, { expiresIn: TOKEN_EXPIRATION });
};

module.exports = generateToken;
