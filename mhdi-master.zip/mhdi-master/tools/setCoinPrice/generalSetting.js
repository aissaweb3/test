const { PrismaClient } = require("@prisma/client");
const prisma = new PrismaClient();

const path = require("path");
require("dotenv").config({ path: path.resolve(__dirname, "../../.env") });

const axios = require("axios");

async function getCryptoPriceCMC(cryptoSymbol, convertCurrency, apiKey) {
  try {
    const url =
      "https://pro-api.coinmarketcap.com/v1/cryptocurrency/quotes/latest";
    const response = await axios.get(url, {
      params: {
        symbol: cryptoSymbol,
        convert: convertCurrency,
      },
      headers: {
        "X-CMC_PRO_API_KEY": apiKey,
      },
    });
    const data = response.data;
    return data.data[cryptoSymbol].quote[convertCurrency].price;
  } catch (error) {
    console.error("Error fetching the cryptocurrency price:", error);
  }
}

const { CMC_API_KEY } = process.env;

const fetchPrice = async (name) => {
  const priceNow = getCryptoPriceCMC(name, "USD", CMC_API_KEY);
  return priceNow;
};

const setCoinPriceTo = async () => {
  const unstableCoins = await prisma.coin.findMany({
    where: {
      //isStable: false,
    },
  });

  let updatedCoinNames = new Set();

  for (const coin of unstableCoins) {
    const { name } = coin;

    if (!updatedCoinNames.has(name)) {
      const priceNow = await fetchPrice(name);
      try {
        await prisma.coin.updateMany({
          where: { name },
          data: { priceOfCoin: priceNow },
        });
        //console.log("price set for", name);

        updatedCoinNames.add(name);
      } catch (error) {
        console.log(error);
      }
    }
  }

  console.log("Price updated.");
};

module.exports = setCoinPriceTo;
