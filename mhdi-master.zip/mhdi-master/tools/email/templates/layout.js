const header = ``;
const footer = ``;

module.exports = { header, footer };
