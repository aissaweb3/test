const { header, footer } = require("./layout");

const subject = "Welcome To PAYOXE";

const template = `
<h1>Welcome To PAYOXE</h1>
`;

module.exports = { text: header + template + footer, subject };
