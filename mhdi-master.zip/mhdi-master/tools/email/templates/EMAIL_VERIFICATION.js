const { header, footer } = require("./layout");

const subject = "Verify Your Email";

const template = `
<h1>Verify Your Email</h1>
`;

module.exports = { text: header + template + footer, subject };
