const send = require("./send");

const sendGeneral = (to, template) => {
  const { subject, text } = require("./templates/" + template);
  send(to, subject, text);
};

module.exports = sendGeneral;
