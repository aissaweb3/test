

const verifyReq = `Please verify your email`


const MerchantCryptoOrderCreated = (amountUSD, amountOfCoin, coin) => {
    return `
<h3>User created a crypto order ${amountUSD}$</h3>
<p>${amountOfCoin} ${coin}</p>
`
}

const UserCryptoOrderCreated = (amountUSD, amountOfCoin, coin) => {
    return `
<h3>You have created a crypto order ${amountUSD}$</h3>
<p>${amountOfCoin} ${coin}</p>
`
}

const SellerPaymentSuccessfull = (amountOfCoin, coin) => {
    return `
<h3>Päyment Successfull</h3>
<p>${amountOfCoin} ${coin}</p>
`
}

const BuyerPaymentSuccessfull = (amountOfCoin, coin) => {
    return `
<h3>Päyment Successfull</h3>
<p>${amountOfCoin} ${coin}</p>
`
}


const ProblemWithWebsite = ()=>{
    return `
<h3>there is a problem with your website</h3>
<p>make sure you follow the documentation properly</p>
`
}


module.exports = {
    verifyReq,
    SellerPaymentSuccessfull,
    BuyerPaymentSuccessfull,
    MerchantCryptoOrderCreated,
    UserCryptoOrderCreated,
    ProblemWithWebsite,
};
