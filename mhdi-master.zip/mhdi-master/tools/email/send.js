const path = require("path");
require("dotenv").config({ path: path.resolve(__dirname, "../../.env") });

const nodemailer = require("nodemailer");

const send = (to, subject, text) => {
  return console.log("Email sent to " + to);

  let transporter = nodemailer.createTransport({
    host: "smtp.gmail.com",
    port: 587,
    secure: false, // true for 465, false for other ports
    auth: {
      user: process.env.EMAIL_USER, // your to from .env
      pass: process.env.EMAIL_PASS, // your password from .env
    },
  });

  let mailOptions = {
    from: process.env.EMAIL_USER, // sender address
    to: to, // list of receivers
    subject, // Subject line
    text,
  };

  // Send to
  transporter.sendMail(mailOptions, (error, info) => {
    if (error) {
      console.log("Error occurred:", error.message);
      return process.exit(1);
    }

    console.log("Email sent to " + to);
  });
};
module.exports = send;
